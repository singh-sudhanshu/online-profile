package com.wipro.profile.risk.assessment.model;

public class AssessmentResult {
	
	private Integer profileScore;
	private String profileName;
	
	public Integer getProfileScore() {
		return profileScore;
	}
	public void setProfileScore(Integer profileScore) {
		this.profileScore = profileScore;
	}
	public String getProfileName() {
		return profileName;
	}
	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}
}
